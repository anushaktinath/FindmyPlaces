//
//  ListView.swift
//  FindmyPlaces
//
//  Created by Mishra, Anu (US - Mumbai) on 9/18/17.
//  Copyright © 2017 Mishra, Anu (US - Mumbai). All rights reserved.
//

import UIKit

protocol PickerViewControllerDelegate: class {
  func pickerControllerDidSelectCancel(_ controller: PickerViewController)
  func category(_ controller: PickerViewController, didSelect value: String , for item: String!)
}

final class PickerViewController: UIViewController {
  
  // MARK: - Properties
  
  var selectedQuantity: String!
  weak var delegate: PickerViewControllerDelegate?
  var rowValues: [String]!
  var item: String!

  
  /*
  var max: Int {
    return categories.count
  }
 */
  
  @IBOutlet weak var pickerView: UIPickerView!
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.pickerView.selectRow(0, inComponent: 0, animated: true)
  }
  
  override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
  }
  
  // MARK: - @IBAction
  
  @IBAction func didSelectCancelButton(_ sender: UIBarButtonItem) {
    self.delegate?.pickerControllerDidSelectCancel(self)
  }
  
  @IBAction func didSelectApplyButton(_ sender: UIBarButtonItem) {
    self.delegate?.category(self, didSelect: self.selectedQuantity, for: item)
  }
}

extension PickerViewController: UIPickerViewDataSource {
  
  public func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
  }
  
  func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return rowValues.count
  }
}


extension PickerViewController: UIPickerViewDelegate {
  
  func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return rowValues[row]
  }
  
  func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
    self.selectedQuantity = rowValues[row]
  }
  
}
